#include <bits/stdc++.h>
using namespace std;
 
#define MAXN 300005
 
int N, E[2], X[2];
int S[2][MAXN], T[2][MAXN], D[2][MAXN];
 
int main()
{
    scanf("%d%d%d%d%d", &N, E, E+1, X, X+1);
    for (int t=0;t<2;t++) for (int i=1;i<=N;i++) scanf("%d", S[t]+i);
    for (int t=0;t<2;t++) for (int i=1;i<N;i++) scanf("%d", T[t]+i);
    for (int i=0;i<2;i++) for (int j=1;j<=N;j++) D[i][j] = 2e9;
    for (int i=0;i<2;i++) D[i][1] = E[i] + S[i][1];
    for (int j=1;j<N;j++) for (int i=0;i<2;i++){
        D[i][j+1] = min(D[i][j+1], D[i][j] + S[i][j+1]);
        D[1-i][j+1] = min(D[1-i][j+1], D[i][j] + T[i][j] + S[1-i][j+1]);
    }
    int ans = min(D[0][N] + X[0], D[1][N] + X[1]);
    printf("%d\n", ans);
}