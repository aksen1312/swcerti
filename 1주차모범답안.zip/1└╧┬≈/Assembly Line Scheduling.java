import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
 
public class source {
    static int N;
    static int[] E, X;
    static int[][] S, T, D;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        E = new int[2]; X = new int[2];
        N = Integer.parseInt(st.nextToken());
        E[0] = Integer.parseInt(st.nextToken());
        E[1] = Integer.parseInt(st.nextToken());
        X[0] = Integer.parseInt(st.nextToken());
        X[1] = Integer.parseInt(st.nextToken());
        S = new int[2][N+1];
        T = new int[2][N];
        for (int i=0;i<2;i++){
            st = new StringTokenizer(br.readLine());
            for (int j=1;j<=N;j++) S[i][j] = Integer.parseInt(st.nextToken());
        }
        for (int i=0;i<2;i++){
            st = new StringTokenizer(br.readLine());
            for (int j=1;j<N;j++) T[i][j] = Integer.parseInt(st.nextToken());
        }
        D = new int[2][N+1];
        for (int i=0;i<2;i++) D[i][1] = E[i] + S[i][1];
        for (int j=2;j<=N;j++){
            for (int i=0;i<2;i++){
                D[i][j] = Math.min(D[i][j-1], D[1-i][j-1] + T[1-i][j-1]) + S[i][j];
            }
        }
        System.out.println(Math.min(D[0][N] + X[0], D[1][N] + X[1]));
    }
}