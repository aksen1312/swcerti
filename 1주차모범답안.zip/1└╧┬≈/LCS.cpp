#include <bits/stdc++.h>
using namespace std;
 
#define pb push_back
#define all(v) (v).begin(), (v).end()
  
int N, M, D[2][1004];
char A[1004], B[1004], F[1004][1004];
  
int main()
{
    scanf("%s%s", A+1, B+1);
    N = strlen(A+1), M = strlen(B+1);
    for (int i=0;i<=N;i++){
        int t = i&1;
        for (int j=0;j<=M;j++) D[!t][j] = -1;
        for (int j=0;j<=M;j++){
            if (j < M && D[t][j+1] < D[t][j]) D[t][j+1] = D[t][j], F[i][j+1] = 1;
            if (D[!t][j] < D[t][j]) D[!t][j] = D[t][j], F[i+1][j] = 2;
            if (i < N && j < M && A[i+1] == B[j+1] && D[!t][j+1] < D[t][j]+1) D[!t][j+1] = D[t][j]+1, F[i+1][j+1] = 3;
        }
    }
    string s;
    for (int i=N,j=M;i>0&&j>0;){
        if (F[i][j] == 1) j--;
        else if (F[i][j] == 2) i--;
        else if (F[i][j] == 3){
            s.pb(A[i]);
            i--; j--;
        }
    }
    reverse(all(s));
    puts(s.c_str());
}