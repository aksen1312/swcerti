import java.io.BufferedReader;
import java.io.InputStreamReader;
 
public class source {
    static int N, M;
    static String A, B;
    static int[][] D, F;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        A = br.readLine();
        B = br.readLine();
        N = A.length(); M = B.length();
        D = new int[N+1][M+1]; F = new int[N+1][M+1];
        for (int i=1;i<=N;i++) for (int j=1;j<=M;j++){
            D[i][j] = D[i][j-1];
            if (D[i][j] < D[i-1][j]){
                D[i][j] = D[i-1][j];
                F[i][j] = 1; // from up
            }
            if (A.charAt(i-1) == B.charAt(j-1) && D[i][j] < D[i-1][j-1]+1){
                D[i][j] = D[i-1][j-1]+1;
                F[i][j] = 2; // from up-left
            }
        }
        String ans = "";
        for (int i=N,j=M;i>0&&j>0;){
            if (F[i][j] == 0){
                j--;
            }else if (F[i][j] == 1){
                i--;
            }else if (F[i][j] == 2){
                i--; j--;
                ans += A.charAt(i);
            }
        }
        System.out.println(new StringBuilder(ans).reverse());
    }
}