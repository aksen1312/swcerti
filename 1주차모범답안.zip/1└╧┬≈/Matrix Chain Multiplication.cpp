#include <bits/stdc++.h>
using namespace std;
 
#define MAXN 503
 
int N;
int A[MAXN];
int cache[MAXN][MAXN];
bool calculated[MAXN][MAXN];
 
int dy(int s, int e)
{
    int &ret = cache[s][e];
    if (calculated[s][e]) return ret;
    calculated[s][e] = 1;
    if (s == e) return ret = 0;
    if (e-s == 1) return ret = A[s] * A[s+1] * A[s+2];
    ret = 2e9;
    for (int k=s;k<e;k++){
        int v = dy(s, k) + dy(k+1, e) + A[s] * A[k+1] * A[e+1];
        ret = min(ret, v);
    }
    return ret;
}
 
int main()
{
    scanf("%d", &N);
    for (int i=1;i<=N+1;i++) scanf("%d", A+i);
    printf("%d\n", dy(1, N));
}