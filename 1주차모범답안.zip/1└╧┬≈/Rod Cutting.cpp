#include <bits/stdc++.h>
using namespace std;
 
int N;
int A[3001], D[3001];
 
int main()
{
    scanf("%d", &N);
    for (int i=1;i<=N;i++) scanf("%d", A+i);
    for (int i=1;i<=N;i++){
        D[i] = A[i];
        for (int j=1;j<i;j++) D[i] = max(D[i], D[i-j] + A[j]);
    }
    printf("%d\n", D[N]);
}