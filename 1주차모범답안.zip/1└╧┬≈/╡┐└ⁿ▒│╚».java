import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
  
public class source {
    static int N, W;
    static int[] A, D;
      
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        A = new int[N+1];
        StringTokenizer st = new StringTokenizer(br.readLine());
        for (int i=1;i<=N;i++) A[i] = Integer.parseInt(st.nextToken());
        W = Integer.parseInt(br.readLine());
        D = new int[W+1];
        for (int i=1;i<=W;i++){
            D[i] = (int)1e9;
            for (int j=1;j<=N;j++) if (i-A[j] >= 0){
                D[i] = Math.min(D[i], D[i-A[j]]+1);
            }
        }
        System.out.println(D[W]);
    }
}