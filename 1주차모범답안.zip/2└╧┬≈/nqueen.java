import java.io.BufferedReader;
import java.io.InputStreamReader;
  
public class source {
    static int N, ans;
    static boolean[] col, d1, d2;
     
    static void dfs(int y) {
        if (y == N){ ans++; return; }
        for (int x=0;x<N;x++){
            if (col[x] || d1[y+x] || d2[y-x+N-1]) continue;
            col[x] = d1[y+x] = d2[y-x+N-1] = true;
            dfs(y+1);
            col[x] = d1[y+x] = d2[y-x+N-1] = false;
        }
    }
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        col = new boolean[N];
        d1 = new boolean[N+N-1]; d2 = new boolean[N+N-1];
        dfs(0);
        System.out.println(ans);
    }
}