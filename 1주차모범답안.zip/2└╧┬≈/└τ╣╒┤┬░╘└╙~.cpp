#include <bits/stdc++.h>
using namespace std;
 
#define pb push_back
 
int yy[]={-1, 0, 1, 0}, xx[]={0, 1, 0, -1};
int N, M, K;
int A[101][101], G[101][101], D[10001];
vector <int> con[10001];
 
void dfs(int y, int x, int g)
{
    G[y][x] = g;
    for (int i=0;i<4;i++){
        int ny = y+yy[i], nx = x+xx[i];
        if (ny < 1 || ny > N || nx < 1 || nx > M || G[ny][nx] || A[y][x] != A[ny][nx]) continue;
        dfs(ny, nx, g);
    }
}
 
int bfs(int s)
{
    for (int i=1;i<=K;i++) D[i] = 2e9;
    queue <int> que;
    D[s] = 0; que.push(s);
    while (!que.empty()){
        int q = que.front(); que.pop();
        for (int t: con[q]){
            if (D[t] < 2e9) continue;
            D[t] = D[q] + 1; que.push(t);
        }
    }
    int ret = 1;
    for (int i=2;i<=N;i++) if (D[ret] < D[i]) ret = i;
    return ret;
}
 
int main()
{
    scanf("%d%d", &N, &M);
    for (int i=1;i<=N;i++) for (int j=1;j<=M;j++) scanf("%d", A[i]+j);
    for (int i=1;i<=N;i++) for (int j=1;j<=M;j++) if (!G[i][j]){
        dfs(i, j, ++K);
    }
    for (int i=1;i<=N;i++) for (int j=1;j<=M;j++){
        for (int d=0;d<4;d++){
            int y = i+yy[d], x = j+xx[d];
            if (y < 1 || x < 1 || y > N || x > M || G[i][j] == G[y][x]) continue;
            con[G[i][j]].pb(G[y][x]);
        }
    }
    int ans = 2e9;
    for (int i=1;i<=K;i++){
        bfs(i);
        int mx = 0;
        for (int j=1;j<=K;j++) mx = max(mx, D[j]);
        ans = min(ans, mx);
    }
    printf("%d\n", ans);
}