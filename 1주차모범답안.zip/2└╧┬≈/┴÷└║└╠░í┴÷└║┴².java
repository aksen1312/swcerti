import java.io.*;
import java.util.*;
  
public class source {
    static int X, N;
    static int[] A;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        X = Integer.parseInt(br.readLine()) * (int)1e7;
        N = Integer.parseInt(br.readLine());
        A = new int[N];
        for (int i=0;i<N;i++) A[i] = Integer.parseInt(br.readLine());
        Arrays.sort(A);
        for (int i=0,r=N-1;i<r;i++){
            while (r > i && A[i]+A[r] > X) r--;
            if (r <= i) break;
            if (A[i]+A[r] == X){
                System.out.printf("yes %d %d\n", A[i], A[r]);
                return;
            }
        }
        System.out.println("danger");
    }
}