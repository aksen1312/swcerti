import java.io.*;
import java.util.*;
  
public class source {
    static int T, A, B;
    static int[] D;
    static boolean[] is_prime;
     
    public static void main(String[] args) throws Exception {
        is_prime = new boolean[10000];
        for (int i=1001;i<10000;i+=2){
            is_prime[i] = true;
            for (int j=2;j*j<=i;j++) if (i % j == 0){
                is_prime[i] = false;
                break;
            }
        }
         
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        T = Integer.parseInt(br.readLine());
        for (int ts=0;ts<T;ts++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            A = Integer.parseInt(st.nextToken());
            B = Integer.parseInt(st.nextToken());   
             
            D = new int[10000];
            for (int i=0;i<10000;i++) D[i] = Integer.MAX_VALUE;
            Queue<Integer> que = new LinkedList<Integer>();
            que.add(A); D[A] = 0;
            while (!que.isEmpty()){
                int q = que.poll();
                for (int b=1;b<10000;b*=10){
                    for (int d=0;d<10;d++){
                        int v = q / b / 10 * b * 10 + q % b + b * d;
                        if (!is_prime[v] || D[v] < Integer.MAX_VALUE) continue;
                        D[v] = D[q]+1;
                        que.add(v);
                    }
                }
            }
            System.out.println(D[B]);
        }
    }
}