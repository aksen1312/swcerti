#include <bits/stdc++.h>
using namespace std;
 
int yy[]={-1, 0, 1, 0}, xx[]={0, 1, 0, -1};
int N;
int A[101][101];
bool V[101][101];
 
bool proc(int m)
{
    for (int mn=A[1][1];mn>=0;mn--){
        int mx = mn + m;
        if (mx < A[1][1]) break;
        for (int i=1;i<=N;i++) for (int j=1;j<=N;j++) V[i][j] = 0;
        queue <int> que;
        que.push(1), que.push(1); V[1][1] = 0;
        while (!que.empty()){
            int y = que.front(); que.pop();
            int x = que.front(); que.pop();
            for (int i=0;i<4;i++){
                int ny = y+yy[i], nx = x+xx[i];
                if (ny < 1 || ny > N || nx < 1 || nx > N || A[ny][nx] < mn || A[ny][nx] > mx || V[ny][nx]) continue;
                V[ny][nx] = 1;
                que.push(ny), que.push(nx);
            }
        }
        if (V[N][N]) return 1;
    }
    return 0;
}
 
int main()
{
    scanf("%d", &N);
    for (int i=1;i<=N;i++) for (int j=1;j<=N;j++) scanf("%d", A[i]+j);
    int s = 0, e = 200, ans;
    while (s <= e){
        int m = s+e >> 1;
        if (proc(m)) e = m-1, ans = m;
        else s = m+1;
    }
    printf("%d\n", ans);
}