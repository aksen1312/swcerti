#include <bits/stdc++.h>
using namespace std;
 
#define MAXN 1000006
typedef long long lld;
 
int N, K;
int A[MAXN];
 
int main()
{
    scanf("%d%d", &N, &K);
    for (int i=1;i<=N;i++) scanf("%d", A+i);
    lld sum = 0;
    deque <int> mn, mx;
    for (int i=1;i<=N;i++){
        sum += A[i];
        if (i > K) sum -= A[i-K];
        while (!mn.empty() && A[mn.back()] >= A[i]) mn.pop_back();
        mn.push_back(i);
        while (!mx.empty() && A[mx.back()] <= A[i]) mx.pop_back();
        mx.push_back(i);
        while (mn.front() <= i-K) mn.pop_front();
        while (mx.front() <= i-K) mx.pop_front();
        if (i >= K)
            printf("%d %d %lld\n", A[mn.front()], A[mx.front()], sum);
    }
}