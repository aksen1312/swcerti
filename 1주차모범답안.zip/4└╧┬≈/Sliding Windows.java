import java.io.*;
import java.util.*;
  
public class source {
    static int N, K;
    static int[] A;
      
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        StringTokenizer st = new StringTokenizer(br.readLine());
        N = Integer.parseInt(st.nextToken());
        K = Integer.parseInt(st.nextToken());
        A = new int[N+1];
        st = new StringTokenizer(br.readLine());
        for (int i=1;i<=N;i++) A[i] = Integer.parseInt(st.nextToken());
        Deque<Integer> mn = new ArrayDeque<Integer>();
        Deque<Integer> mx = new ArrayDeque<Integer>();
        long sum = 0;
        for (int i=1;i<=N;i++){
            while (!mn.isEmpty() && A[mn.getLast()] >= A[i]) mn.pollLast();
            while (!mx.isEmpty() && A[mx.getLast()] <= A[i]) mx.pollLast();
            mn.addLast(i);
            mx.addLast(i);
            sum += A[i];
            if (i > K) sum -= A[i-K];
            while (mn.getFirst() <= i-K) mn.pollFirst();
            while (mx.getFirst() <= i-K) mx.pollFirst();
            if (i >= K)
                bw.write(A[mn.getFirst()] + " " + A[mx.getFirst()] + " " + sum + "\n");
        }
        bw.flush();
        bw.close();
    }
}