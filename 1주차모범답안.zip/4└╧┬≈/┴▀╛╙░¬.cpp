#include <bits/stdc++.h>
using namespace std;
 
int N;
 
int main()
{
    scanf("%d", &N);
    priority_queue <int> P, Q;
    for (int i=1;i<=N;i++){
        int v; scanf("%d", &v);
        if (Q.empty() || v < -Q.top()) P.push(v);
        else Q.push(-v);
        while (P.size() <= Q.size())
            P.push(-Q.top()), Q.pop();
        while (P.size() > Q.size()+1)
            Q.push(-P.top()), P.pop();
        if (i&1) printf("%d\n", P.top());
    }
}