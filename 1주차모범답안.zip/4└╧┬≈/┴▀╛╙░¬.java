import java.io.*;
import java.util.*;
 
public class source {
    static int N;
    static int[] A;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        PriorityQueue<Integer> L = new PriorityQueue<Integer>();
        PriorityQueue<Integer> R = new PriorityQueue<Integer>();
        for (int i=1;i<=N;i++){
            int v = Integer.parseInt(br.readLine());
             
            if (R.isEmpty() || R.peek() > v) L.add(-v);
            else R.add(v);
             
            while (L.size() > R.size()+1)
                R.add(-L.poll());
            while (R.size() > L.size())
                L.add(-R.poll());
             
            if (i % 2 == 1) System.out.println(-L.peek());
        }
    }
}