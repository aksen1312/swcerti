#include <bits/stdc++.h>
using namespace std;
 
typedef long long lld;
 
int N, K;
lld A[52], B[52], C[52];
 
int main()
{
    scanf("%d%d", &N, &K);
    for (int i=1;i<=K;i++) A[i] = B[i] = -1e18;
    for (int i=1;i<=N;i++){
        int v; scanf("%d", &v);
        for (int j=1;j<=K;j++) A[j] += v;
        for (int j=1;j<=K;j++) if (A[j] < v){
            for (int k=K;k>=j;k--) A[k+1] = A[k];
            A[j] = v;
            break;
        }
        for (int j=1,l=1,r=1;j<=K;j++){
            if (A[l] > B[r]) C[j] = A[l++];
            else C[j] = B[r++];
        }
        for (int j=1;j<=K;j++) B[j] = C[j];
    }
    printf("%lld\n", B[K]);
}