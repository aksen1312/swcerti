#include <bits/stdc++.h>
using namespace std;
 
typedef long long lld;
 
int K, N;
int A[101], pt[101];
int X[100001];
 
int main()
{
    scanf("%d%d", &K, &N);
    for (int i=1;i<=K;i++) scanf("%d", A+i);
    X[0] = 1;
    for (int i=1;i<=N;i++){
        lld mn = 1e18;
        for (int j=1;j<=K;j++){
            lld v = (lld)A[j] * X[pt[j]];
            if (mn > v) mn = v;
        }
        X[i] = mn;
        for (int j=1;j<=K;j++){
            while ((lld)A[j] * X[pt[j]] <= mn) pt[j]++;
        }
    }
    printf("%d\n", X[N]);
}