#include <bits/stdc++.h>
using namespace std;
 
#define MAXN 100005
 
int N, Q;
int par[MAXN];
 
int cp(int n){ return par[n] == n ? n : (par[n] = cp(par[n])); }
 
int main()
{
    scanf("%d%d", &N, &Q);
    for (int i=1;i<=N;i++) par[i] = i;
    while (Q--){
        int t, a, b; scanf("%d%d%d", &t, &a, &b);
        if (t){
            printf("%d\n", cp(a) == cp(b));
        }else{
            int ga = cp(a), gb = cp(b);
            par[gb] = ga;
        }
    }
}