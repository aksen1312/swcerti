import java.io.*;
import java.util.*;
  
public class source {
    static int N, Q;
    static int[] A, par;
      
    static int cp(int n) {
        if (par[n] == n) return n;
        return par[n] = cp(par[n]);
    }
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        Q = Integer.parseInt(br.readLine());
        par = new int[N+1];
        for (int i=1;i<=N;i++) par[i] = i;
        while (Q-- > 0){
            StringTokenizer st = new StringTokenizer(br.readLine());
            int t = Integer.parseInt(st.nextToken());
            int a = Integer.parseInt(st.nextToken());
            int b = Integer.parseInt(st.nextToken());
            if (t == 0){
                int p = cp(a), q = cp(b);
                if (p == q) continue;
                par[q] = p;
            }else{
                int p = cp(a), q = cp(b);
                System.out.println(p == q ? 1 : 0);
            }
        }
    }
}