#include <bits/stdc++.h>
using namespace std;
 
#define MAXN 100005
#define TS 262144
typedef long long lld;
 
int N, Q;
int A[MAXN];
int mntree[TS], mxtree[TS], ST=TS/2-1;
lld S[MAXN];
 
int main()
{
    scanf("%d", &N);
    for (int i=1;i<=N;i++) scanf("%d", A+i), S[i] = S[i-1]+A[i];
    for (int i=ST+1;i<TS;i++) mntree[i] = 2e9;
    for (int i=1;i<=N;i++) mntree[ST+i] = mxtree[ST+i] = A[i];
    for (int i=ST;i;i--)
        mntree[i] = min(mntree[i+i], mntree[i+i+1]),
        mxtree[i] = max(mxtree[i+i], mxtree[i+i+1]);
    for (scanf("%d", &Q);Q--;){
        int s, e; scanf("%d%d", &s, &e);
        int mn = A[s], mx = A[s];
        for (int l=ST+s,r=ST+e;l<=r;l>>=1,r>>=1){
            if (l&1) tie(mn, mx) = minmax({mn, mx, mntree[l], mxtree[l]}), l++;
            if (!(r&1)) tie(mn, mx) = minmax({mn, mx, mntree[r], mxtree[r]}), r--;
        }
        printf("%d %d %lld\n", mn, mx, S[e]-S[s-1]);
    }
}