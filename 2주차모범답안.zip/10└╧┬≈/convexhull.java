import java.io.*;
import java.util.*;
 
class Point {
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
     
    int x, y;
}
 
public class source {
    static int N;
    static Point[] A;
     
    static int ccw(int ax, int ay, int bx, int by, int cx, int cy) {
        long v = (long)(bx-ax)*(cy-ay) - (long)(cx-ax)*(by-ay);
        if (v > 0) return 1;
        if (v < 0) return -1;
        return 0;
    }
     
    static int ccw(Point a, Point b, Point c) {
        return ccw(a.x, a.y, b.x, b.y, c.x, c.y);
    }
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        A = new Point[N];
        for (int i=0;i<N;i++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            int x = Integer.parseInt(st.nextToken());
            int y = Integer.parseInt(st.nextToken());
            A[i] = new Point(x, y);
        }
        for (int i=1;i<N;i++){
            if (A[0].y > A[i].y || A[0].y == A[i].y && A[0].x > A[i].x){
                Point tmp = A[0];
                A[0] = A[i];
                A[i] = tmp;
            }
        }
        for (int i=N-1;i>=0;i--){
            A[i].x -= A[0].x;
            A[i].y -= A[0].y;
        }
        Arrays.sort(A, 1, N, new Comparator<Point>() {
            public int compare(Point a, Point b) {
                // sign <=> a - b
                // negtive: a < b
                // potivie: a > b
                // zero: a == b
                // priority
                int v = ccw(new Point(0, 0), a, b);
                if (v > 0) return -1; // 0 -> a: b ccw
                if (v < 0) return 1;
                return (Math.abs(a.x)+a.y) - (Math.abs(b.x)+b.y);
            }
        });
        ArrayList <Integer> stk = new ArrayList<>();
        stk.add(0);
        for (int i=1;i<N;i++){
            while (stk.size() > 1 && ccw(A[stk.get(stk.size()-2)], A[stk.get(stk.size()-1)], A[i]) <= 0){
                stk.remove(stk.size()-1);
            }
            stk.add(i);
        }
        System.out.println(stk.size());
    }
}