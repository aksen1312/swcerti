#include <bits/stdc++.h>
using namespace std;
 
int T;
int ax, ay, bx, by;
 
int ccw(int ax, int ay, int bx, int by, int cx, int cy)
{
    int k = (bx-ax)*(cy-ay)-(cx-ax)*(by-ay);
    if (k > 0) return 1;
    if (k) return -1;
    return 0;
}
 
int proc(int cx, int cy, int dx, int dy)
{
    if (cx == dx){
        // 수직 선분인 경우 양 끝점 포함
        if (ax == bx && ax == cx){
            if (ay > by) swap(ay, by);
            if (dy < ay || by < cy) return 0;
            if (dy == ay || by == cy) return 1;
            return 9;
        }
        return ccw(ax, ay, bx, by, cx, cy) * ccw(ax, ay, bx, by, dx, dy) <= 0 &&
            ccw(cx, cy, dx, dy, ax, ay) * ccw(cx, cy, dx, dy, bx, by) <= 0;
    }else{
        // 수평 선분인 경우 양 끝점 제외
        if (ay == by && ay == cy){
            if (ax > bx) swap(ax, bx);
            if (dx <= ax || bx <= cx) return 0;
            return 9;
        }
        return ccw(ax, ay, bx, by, cx, cy) * ccw(ax, ay, bx, by, dx, dy) < 0 &&
            ccw(cx, cy, dx, dy, ax, ay) * ccw(cx, cy, dx, dy, bx, by) <= 0;
    }
}
 
int main()
{
    for (scanf("%d", &T);T--;){
        int sx, sy, ex, ey;
        scanf("%d%d%d%d", &sx, &sy, &ex, &ey);
        scanf("%d%d%d%d", &ax, &ay, &bx, &by);
        int ans = proc(sx, sy, ex, sy) + proc(sx, ey, ex, ey) + proc(sx, sy, sx, ey) + proc(ex, sy, ex, ey);
        printf("%d\n", min(ans, 4));
    }
}