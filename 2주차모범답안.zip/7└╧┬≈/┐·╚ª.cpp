#include <bits/stdc++.h>
using namespace std;
  
int T, N, M, K;
int D[501];
  
struct Z{
    int a, b, c;
} E[5555];
  
int main()
{
    for (scanf("%d", &T);T--;){
        scanf("%d%d%d", &N, &M, &K);
        for (int i=1;i<=M;i++)
            scanf("%d%d%d", &E[i].a, &E[i].b, &E[i].c),
            E[M+i] = {E[i].b, E[i].a, E[i].c};
        M <<= 1;
        while (K--){
            int a, b, c; scanf("%d%d%d", &a, &b, &c);
            E[++M] = {a, b, -c};
        }
        for (int i=1;i<=N;i++) D[i] = 0;
        bool broken = 0;
        for (int i=1;i<=N;i++){
            bool sw = 0;
            for (int j=1;j<=M;j++){
                if (D[E[j].b] > D[E[j].a] + E[j].c)
                    D[E[j].b] = D[E[j].a] + E[j].c, sw = 1;
            }
            if (!sw){ broken = 1; break; }
        }
        puts(broken ? "NO" : "YES");
    }
}