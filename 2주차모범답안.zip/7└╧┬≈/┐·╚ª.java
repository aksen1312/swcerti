import java.io.*;
import java.util.*;
 
class Edge {
    public Edge(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
 
    int a, b, c;
}
 
public class source {
    static int T, N, M, W;
    static int[] dist;
    static ArrayList <Edge> edges;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        T = Integer.parseInt(br.readLine());
        for (int ts=0;ts<T;ts++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            N = Integer.parseInt(st.nextToken());
            M = Integer.parseInt(st.nextToken());
            W = Integer.parseInt(st.nextToken());
            edges = new ArrayList<>();
            for (int i=1;i<=M;i++){
                st = new StringTokenizer(br.readLine());
                int a = Integer.parseInt(st.nextToken());
                int b = Integer.parseInt(st.nextToken());
                int c = Integer.parseInt(st.nextToken());
                edges.add(new Edge(a, b, c));
                edges.add(new Edge(b, a, c));
            }
            for (int i=1;i<=W;i++){
                st = new StringTokenizer(br.readLine());
                int a = Integer.parseInt(st.nextToken());
                int b = Integer.parseInt(st.nextToken());
                int c = Integer.parseInt(st.nextToken());
                edges.add(new Edge(a, b, -c));
            }
            dist = new int[N+1];
            boolean stopped = false;
            for (int t=1;t<=N;t++){
                boolean sw = false;
                for (Edge e: edges){
                    if (dist[e.b] > dist[e.a] + e.c){
                        dist[e.b] = dist[e.a] + e.c;
                        sw = true;
                    }
                }
                if (!sw){
                    stopped = true;
                    break;
                }
            }
            System.out.println(stopped ? "NO" : "YES");
        }
    }
}