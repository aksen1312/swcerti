import java.io.*;
import java.util.*;
 
public class source {
    static int N;
    static int[] dep;
    static int[][] par;
    static ArrayList<Integer>[] con;
     
    static int lca(int a, int b) {
        if (dep[a] < dep[b]) return lca(b, a);
        for (int i=0;i<17;i++) if (((dep[b]-dep[a])&(1<<i)) > 0) a = par[a][i];
        if (a == b) return a;
        for (int i=17;i-->0;) if (par[a][i] != par[b][i]){
            a = par[a][i];
            b = par[b][i];
        }
        return par[a][0];
    }
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        con = new ArrayList[N+1];
        for (int i=1;i<=N;i++) con[i] = new ArrayList<>();
        for (int i=1;i<N;i++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            int a = Integer.parseInt(st.nextToken());
            int b = Integer.parseInt(st.nextToken());
            con[a].add(b);
            con[b].add(a);
        }
        dep = new int[N+1]; par = new int[N+1][17];
        Queue <Integer> que = new LinkedList<>();
        que.add(1);
        while (!que.isEmpty()){
            int q = que.poll();
            for (int t: con[q]) if (par[q][0] != t){
                par[t][0] = q; dep[t] = dep[q]+1;
                que.add(t);
            }
        }
        for (int i=1;i<17;i++) for (int j=1;j<=N;j++){
            par[j][i] = par[par[j][i-1]][i-1];
        }
        long ans = 0;
        for (int i=1;i<N;i++){
            int j = i+1, k = lca(i, j);
            ans += dep[i] + dep[j] - 2*dep[k];
        }
        System.out.println(ans);
    }
}