import java.io.*;
import java.util.*;
 
public class source {
    static int N;
    static int[] cnt = new int[2];
    static int[][] A;
     
    static void dfs(int y, int x, int sz) {
        boolean all_same = true;
        for (int i=0;i<sz;i++) for (int j=0;j<sz;j++) if (A[y][x] != A[y+i][x+j]) all_same = false;
        if (all_same){
            cnt[A[y][x]]++;
            return;
        }
        int z = sz / 2;
        dfs(y, x, z);
        dfs(y+z, x, z);
        dfs(y, x+z, z);
        dfs(y+z, x+z, z);
    }
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        N = Integer.parseInt(br.readLine());
        A = new int[N+1][N+1];
        for (int i=1;i<=N;i++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            for (int j=1;j<=N;j++) A[i][j] = Integer.parseInt(st.nextToken());
        }
        dfs(1, 1, N);
        for (int i=0;i<2;i++) System.out.println(cnt[i]);
    }
}