import java.io.*;
import java.util.*;
 
public class source {
    static int L, N, B;
    static int[] W, C, F;
    static ArrayList<Integer>[] list;
    static int[][] D;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        L = Integer.parseInt(st.nextToken());
        N = Integer.parseInt(st.nextToken());
        B = Integer.parseInt(st.nextToken());
        W = new int[N+1]; C = new int[N+1]; F = new int[N+1];
        list = new ArrayList[L];
        for (int i=0;i<L;i++) list[i] = new ArrayList<>();
        for (int i=1;i<=N;i++){
            st = new StringTokenizer(br.readLine());
            int x = Integer.parseInt(st.nextToken());
            W[i] = Integer.parseInt(st.nextToken());
            F[i] = Integer.parseInt(st.nextToken());
            C[i] = Integer.parseInt(st.nextToken());
            list[x].add(i);
        }
        D = new int[L+1][B+1];
        for (int i=0;i<=L;i++) for (int j=0;j<=B;j++) D[i][j] = Integer.MIN_VALUE;
        D[0][0] = 0;
        for (int i=0;i<L;i++) for (int j=0;j<=B;j++) if (D[i][j] > Integer.MIN_VALUE){
            for (int k: list[i]){
                if (j + C[k] <= B &&
                    D[i + W[k]][j + C[k]] < D[i][j] + F[k])
                    D[i + W[k]][j + C[k]] = D[i][j] + F[k];
            }
        }
        int ans = -1;
        for (int i=0;i<=B;i++) ans = Math.max(ans, D[L][i]);
        System.out.println(ans);
    }
}