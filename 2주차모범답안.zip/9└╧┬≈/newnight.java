import java.io.*;
import java.util.*;
 
public class source {
    static int T, N, M;
    static char[][] A;
    static int[][][][] D;
     
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        T = Integer.parseInt(br.readLine());
        for (int ts=0;ts<T;ts++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            N = Integer.parseInt(st.nextToken());
            M = Integer.parseInt(st.nextToken());
            A = new char[N+1][M+1];
            for (int i=1;i<=N;i++){
                String s = br.readLine();
                for (int j=1;j<=M;j++) A[i][j] = s.charAt(j-1);
            }
            D = new int[N+1][M+1][1<<M][2];
            for (int i=0;i<=N;i++) for (int j=0;j<=M;j++) for (int k=0;k<(1<<M);k++) for (int t=0;t<2;t++){
                D[i][j][k][t] = Integer.MIN_VALUE;
            }
            D[N][M][0][0] = 0;
            for (int i=N;i>0;i--){
                for (int j=M;j>0;j--){
                    for (int msk=0;msk<(1<<M);msk++) for (int t=0;t<2;t++) if (D[i][j][msk][t] >= 0){
                        int nmsk = msk;
                        // nmsk의 2 ** (j-1) 해당 비트를 0으로 만들어준 것
                        if ((nmsk & (1 << (j-1))) > 0)
                            nmsk ^= (1 << (j-1));
                        int nt = (msk >> (j-1)) & 1;
                        if (D[i][j-1][nmsk][nt] < D[i][j][msk][t])
                            D[i][j-1][nmsk][nt] = D[i][j][msk][t];
                        if (A[i][j] == &#39;x&#39; || (msk&(1<<j)) > 0 ||
                                t > 0 || (j > 1 && (msk & (1 << (j-2))) > 0)) continue;
                        nmsk ^= 1 << (j-1);
                        if (D[i][j-1][nmsk][nt] < D[i][j][msk][t] + 1)
                            D[i][j-1][nmsk][nt] = D[i][j][msk][t] + 1;
                    }
                }
                for (int msk=0;msk<(1<<M);msk++) for (int t=0;t<2;t++){
                    if (D[i-1][M][msk][0] < D[i][0][msk][t])
                        D[i-1][M][msk][0] = D[i][0][msk][t];
                }
            }
            int ans = 0;
            for (int msk=0;msk<(1<<M);msk++) ans = Math.max(ans, D[0][M][msk][0]);
            System.out.println(ans);
        }
    }
}